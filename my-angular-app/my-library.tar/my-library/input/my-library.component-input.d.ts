import * as i0 from "@angular/core";
export declare class MyLibraryInputComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyLibraryInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyLibraryInputComponent, "lib-my-library-input", never, {}, {}, never, never, true, never>;
}
