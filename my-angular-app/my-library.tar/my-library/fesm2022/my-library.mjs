/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=my-library.mjs.map
