import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  Component,
  setClassMetadata,
  ɵɵStandaloneFeature,
  ɵɵdefineComponent,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";

// my-library/fesm2022/my-library-input.mjs
var MyLibraryInputComponent = class _MyLibraryInputComponent {
  static ɵfac = function MyLibraryInputComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _MyLibraryInputComponent)();
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _MyLibraryInputComponent,
    selectors: [["lib-my-library-input"]],
    standalone: true,
    features: [ɵɵStandaloneFeature],
    decls: 5,
    vars: 0,
    consts: [[1, "bg-blue-500", "text-red", "p-4", "rounded-lg"], [1, "text-xl", "font-bold"]],
    template: function MyLibraryInputComponent_Template(rf, ctx) {
      if (rf & 1) {
        ɵɵelementStart(0, "div", 0)(1, "h1", 1);
        ɵɵtext(2, "Componente con Tailwind CSS..");
        ɵɵelementEnd();
        ɵɵelementStart(3, "p");
        ɵɵtext(4, "Este componente usa clases de Tailwind CSS embebidas...");
        ɵɵelementEnd()();
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyLibraryInputComponent, [{
    type: Component,
    args: [{
      selector: "lib-my-library-input",
      standalone: true,
      imports: [],
      template: `
    <div class="bg-blue-500 text-red p-4 rounded-lg">
  <h1 class="text-xl font-bold">Componente con Tailwind CSS..</h1>
  <p>Este componente usa clases de Tailwind CSS embebidas...</p>
</div>
  `
    }]
  }], null, null);
})();
export {
  MyLibraryInputComponent
};
//# sourceMappingURL=my-library_input.js.map
