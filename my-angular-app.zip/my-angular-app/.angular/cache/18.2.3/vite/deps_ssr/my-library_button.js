import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  Component,
  setClassMetadata,
  ɵɵStandaloneFeature,
  ɵɵdefineComponent,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext
} from "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";

// my-library/fesm2022/my-library-button.mjs
var MyLibraryButtonComponent = class _MyLibraryButtonComponent {
  static ɵfac = function MyLibraryButtonComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _MyLibraryButtonComponent)();
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _MyLibraryButtonComponent,
    selectors: [["lib-my-library-button"]],
    standalone: true,
    features: [ɵɵStandaloneFeature],
    decls: 5,
    vars: 0,
    consts: [[1, "bg-red-500", "text-red", "p-4", "rounded-lg"], [1, "text-xl", "font-bold"]],
    template: function MyLibraryButtonComponent_Template(rf, ctx) {
      if (rf & 1) {
        ɵɵelementStart(0, "div", 0)(1, "h1", 1);
        ɵɵtext(2, "Componente con Tailwind CSS..");
        ɵɵelementEnd();
        ɵɵelementStart(3, "p");
        ɵɵtext(4, "Este componente usa clases de Tailwind CSS embebidas...");
        ɵɵelementEnd()();
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyLibraryButtonComponent, [{
    type: Component,
    args: [{
      selector: "lib-my-library-button",
      standalone: true,
      imports: [],
      template: `
    <div class="bg-red-500 text-red p-4 rounded-lg">
  <h1 class="text-xl font-bold">Componente con Tailwind CSS..</h1>
  <p>Este componente usa clases de Tailwind CSS embebidas...</p>
</div>
  `
    }]
  }], null, null);
})();
export {
  MyLibraryButtonComponent
};
//# sourceMappingURL=my-library_button.js.map
