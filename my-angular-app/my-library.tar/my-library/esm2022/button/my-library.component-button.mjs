import { Component } from '@angular/core';
import * as i0 from "@angular/core";
export class MyLibraryButtonComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.3", type: MyLibraryButtonComponent, isStandalone: true, selector: "lib-my-library-button", ngImport: i0, template: `
    <p>
      my-library works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-my-library-button', standalone: true, imports: [], template: `
    <p>
      my-library works!
    </p>
  ` }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXktbGlicmFyeS5jb21wb25lbnQtYnV0dG9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvbXktbGlicmFyeS9idXR0b24vbXktbGlicmFyeS5jb21wb25lbnQtYnV0dG9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBYTFDLE1BQU0sT0FBTyx3QkFBd0I7dUdBQXhCLHdCQUF3QjsyRkFBeEIsd0JBQXdCLGlGQVB6Qjs7OztHQUlUOzsyRkFHVSx3QkFBd0I7a0JBWHBDLFNBQVM7K0JBQ0UsdUJBQXVCLGNBQ3JCLElBQUksV0FDUCxFQUFFLFlBQ0Q7Ozs7R0FJVCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdsaWItbXktbGlicmFyeS1idXR0b24nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgdGVtcGxhdGU6IGBcbiAgICA8cD5cbiAgICAgIG15LWxpYnJhcnkgd29ya3MhXG4gICAgPC9wPlxuICBgLFxuICBzdHlsZXM6IGBgXG59KVxuZXhwb3J0IGNsYXNzIE15TGlicmFyeUJ1dHRvbkNvbXBvbmVudCB7XG5cbn1cbiJdfQ==