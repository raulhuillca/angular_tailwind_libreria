import { Component } from '@angular/core';
import * as i0 from "@angular/core";
export class MyLibraryInputComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.3", type: MyLibraryInputComponent, isStandalone: true, selector: "lib-my-library-input", ngImport: i0, template: `
    <p>
      my-library works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-my-library-input', standalone: true, imports: [], template: `
    <p>
      my-library works!
    </p>
  ` }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXktbGlicmFyeS5jb21wb25lbnQtaW5wdXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9teS1saWJyYXJ5L2lucHV0L215LWxpYnJhcnkuY29tcG9uZW50LWlucHV0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBYTFDLE1BQU0sT0FBTyx1QkFBdUI7dUdBQXZCLHVCQUF1QjsyRkFBdkIsdUJBQXVCLGdGQVB4Qjs7OztHQUlUOzsyRkFHVSx1QkFBdUI7a0JBWG5DLFNBQVM7K0JBQ0Usc0JBQXNCLGNBQ3BCLElBQUksV0FDUCxFQUFFLFlBQ0Q7Ozs7R0FJVCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdsaWItbXktbGlicmFyeS1pbnB1dCcsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxuICB0ZW1wbGF0ZTogYFxuICAgIDxwPlxuICAgICAgbXktbGlicmFyeSB3b3JrcyFcbiAgICA8L3A+XG4gIGAsXG4gIHN0eWxlczogYGBcbn0pXG5leHBvcnQgY2xhc3MgTXlMaWJyYXJ5SW5wdXRDb21wb25lbnQge1xuXG59XG4iXX0=