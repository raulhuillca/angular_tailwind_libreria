import * as i0 from "@angular/core";
export declare class MyLibraryButtonComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyLibraryButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyLibraryButtonComponent, "lib-my-library-button", never, {}, {}, never, never, true, never>;
}
