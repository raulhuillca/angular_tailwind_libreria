import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class MyLibraryInputComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.3", type: MyLibraryInputComponent, isStandalone: true, selector: "lib-my-library-input", ngImport: i0, template: `
    <p>
      my-library works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.3", ngImport: i0, type: MyLibraryInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-my-library-input', standalone: true, imports: [], template: `
    <p>
      my-library works!
    </p>
  ` }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MyLibraryInputComponent };
//# sourceMappingURL=my-library-input.mjs.map
