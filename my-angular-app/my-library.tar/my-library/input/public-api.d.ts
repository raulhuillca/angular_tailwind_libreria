export * from './my-library.component-input';
